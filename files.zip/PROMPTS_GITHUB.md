# Civil IA Lab – Guía de Prompts para GitHub Pages

Todo lo que necesitas para subir y personalizar tu página web en GitHub.

---

## PASO 0 — Crear el repositorio en GitHub

**Prompt para el chat de GitHub Copilot o para pedirle ayuda a alguien:**

> Crea un repositorio público en GitHub llamado `civil-ia-lab`. Sube el archivo `index.html` a la raíz del repositorio. Luego ve a **Settings → Pages**, selecciona la rama `main` y la carpeta raíz `/`, y activa GitHub Pages. La URL pública quedará en: `https://TU_USUARIO.github.io/civil-ia-lab/`

---

## PROMPT 1 — Actualizar los links de YouTube

Busca en el archivo `index.html` todas las ocurrencias de `TU_LINK_YOUTUBE` y reemplázalas por el URL real de cada video.  
Ejemplo: `href="https://www.youtube.com/watch?v=XXXXXXXXX"`  
Hay 5 tarjetas (una por tema) + 1 en la sección de redes sociales.

---

## PROMPT 2 — Actualizar los links de TikTok

Busca todas las ocurrencias de `TU_LINK_TIKTOK` y reemplázalas por el URL real de cada video de TikTok.  
Hay 5 tarjetas + 1 en la sección de redes sociales.

---

## PROMPT 3 — Actualizar los links de Instagram

Busca todas las ocurrencias de `TU_LINK_INSTAGRAM` y reemplázalas.  
Hay 5 tarjetas + 1 en la sección de redes sociales.

---

## PROMPT 4 — Actualizar los handles de redes sociales

En la sección `id="redes"`, actualiza los tres campos:  
- El `@handle` dentro de `.red-handle`  
- El link en `href="..."`  
- El texto de `.red-link`  

Con los nombres reales de sus cuentas de YouTube, TikTok e Instagram.

---

## PROMPT 5 — Agregar imágenes reales al proceso de elaboración

Cada `.proceso-img-placeholder` debe reemplazarse por una etiqueta `<img>`.  
Sube tus fotos o capturas a una carpeta `/img/` dentro del repositorio y usa:

```html
<img src="img/tema01-proceso.jpg" alt="Proceso Tema 1" 
     style="width:100%;border-radius:8px;object-fit:cover;height:180px;" />
```

Repite para tema02, tema03, tema04 y tema05.

---

## PROMPT 6 — Agregar los títulos y descripciones reales de cada tema

En la sección `id="trabajos"`, dentro de cada `.trabajo-card`, actualiza:  
- `.trabajo-title` → el título exacto como lo llamaron ustedes  
- `.trabajo-desc` → una descripción de 2–3 líneas del contenido investigado  

Usa únicamente información verificada de sus fuentes (Código Civil, Constitución, LEXIS, etc.).

---

## PROMPT 7 — Personalizar el proceso de elaboración de cada tema

En la sección `id="proceso"`, dentro de cada `.proceso-info p`, reemplaza el texto con  
la descripción real del proceso que siguieron: qué artículos revisaron, qué casos analizaron,  
cómo usaron la IA, qué produjo el equipo. En las `<ul>` actualiza cada `<li>` con los pasos reales.

---

## PROMPT 8 — Añadir un video embebido de YouTube dentro de cada tarjeta

Si quieres que el video se reproduzca directamente en la página (no solo un link),  
dentro de `.trabajo-media` de cada tarjeta agrega:

```html
<div style="position:relative;padding-bottom:56.25%;height:0;overflow:hidden;border-radius:8px;margin-top:.8rem;">
  <iframe 
    src="https://www.youtube.com/embed/ID_DEL_VIDEO"
    style="position:absolute;top:0;left:0;width:100%;height:100%;border:0;"
    allowfullscreen loading="lazy">
  </iframe>
</div>
```

Reemplaza `ID_DEL_VIDEO` con el código de 11 caracteres de cada video de YouTube.

---

## PROMPT 9 — Agregar un embed de Instagram (Reels)

Dentro de `.trabajo-media` agrega el embed oficial de Instagram:

```html
<blockquote class="instagram-media" 
  data-instgrm-permalink="https://www.instagram.com/reel/TU_ID_REEL/"
  data-instgrm-version="14">
</blockquote>
<script async src="//www.instagram.com/embed.js"></script>
```

---

## PROMPT 10 — Cambiar colores si cambia la paleta UTN

Los colores están definidos como variables CSS al inicio del `<style>`. Solo edita:

```css
--red:      #C8102E;   /* rojo UTN principal */
--red-dark: #8B0B1F;   /* rojo oscuro para hover */
--black:    #0D0D0D;   /* fondo principal */
--gray-dk:  #1A1A1A;   /* fondo secciones alternas */
--white:    #F5F5F5;   /* texto principal */
```

---

## PROMPT 11 — Conectar el formulario de contacto a un servicio real

El formulario actual no envía datos. Para activarlo sin backend, usa **Formspree**:

1. Crea cuenta gratuita en https://formspree.io  
2. Crea un formulario y copia tu endpoint (ej: `https://formspree.io/f/XXXXXXXX`)  
3. En el HTML, cambia la etiqueta del formulario de:  
   ```html
   <form class="contact-form" onsubmit="return false;">
   ```  
   a:  
   ```html
   <form class="contact-form" action="https://formspree.io/f/XXXXXXXX" method="POST">
   ```
4. Cambia el `<button type="submit">` para que funcione normalmente.

---

## PROMPT 12 — Agregar logo UTN en el hero

Descarga el logo de la UTN en PNG (fondo transparente) y súbelo como `/img/utn-logo.png`.  
Dentro del `<div class="hero-content">`, antes del `<p class="hero-eyebrow">`, agrega:

```html
<img src="img/utn-logo.png" alt="Universidad Técnica del Norte" 
     style="height:56px;margin-bottom:1.5rem;opacity:.85;filter:brightness(0) invert(1);" />
```

---

## PROMPT 13 — Agregar foto grupal en la sección Quiénes Somos

Sube la foto del equipo como `/img/equipo.jpg`. Después del bloque `.qs-grid` agrega:

```html
<div style="margin-top:3rem;border-radius:12px;overflow:hidden;border:1px solid rgba(255,255,255,.08);">
  <img src="img/equipo.jpg" alt="Equipo Civil IA Lab" 
       style="width:100%;max-height:420px;object-fit:cover;" />
</div>
```

---

## PROMPT 14 — Estructura de archivos recomendada para GitHub

```
civil-ia-lab/
├── index.html
├── img/
│   ├── utn-logo.png
│   ├── equipo.jpg
│   ├── tema01-proceso.jpg
│   ├── tema02-proceso.jpg
│   ├── tema03-proceso.jpg
│   ├── tema04-proceso.jpg
│   └── tema05-proceso.jpg
└── README.md
```

---

## PROMPT 15 — README.md básico para el repositorio

```markdown
# Civil IA Lab

Página web oficial del semillero de investigación **Civil IA Lab** de la  
Universidad Técnica del Norte, Carrera de Derecho — Ibarra, Ecuador.

**Proyecto:** Investigación dinámica del Derecho Civil Ecuatoriano mediante  
inteligencia artificial y gamificación jurídica.

**Equipo:** Torres Andrade Hugo Patricio (docente) · Torres Trujillo Damaris ·  
Montenegro España Mateo · Guamialamá Vásquez Andrea · Quishpe Mera Juan Carlos

**Sitio:** https://TU_USUARIO.github.io/civil-ia-lab/
```

---

*Todos los prompts anteriores están pensados para editar directamente el archivo `index.html`  
con cualquier editor de texto (VS Code, Notepad++, el editor de GitHub en línea, etc.).*
